import java.util.Scanner;


public class electricitybill
{

    public static void main(String[] args) {
        int min_charge;
        int units;
        int a;
        min_charge = 100;
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the units charged ");
        int num = scan.nextInt();
        scan.close();
        units = num;
        if (units < 11){
            System.out.println(min_charge);
        } 
        else if (units >= 11 && units <= 50 ){
            units = units - 10; 
            a = min_charge + (units * 5);
            System.out.println("Your bill is "+a);
        } 
        else if (units >= 51 && units <= 200){
            units = units - 10;
            int b = units - 40;
            a = min_charge + (40 * 5) + (b * 10); 
            System.out.println("Your bill is "+a);
        } 
        else if (units >= 201 && units <= 500){
            units = units - 10;
            int b = units - 40 - 150;
            a = min_charge + (40 * 5) + (150 * 10) + (b * 15);
            System.out.println("Your bill is "+a);
        } 
        else if (units > 500){
            units = units - 10;
            int b = units - 40 - 150 - 300;
            a = min_charge + (40 * 5) + (150 * 10)+ (300 * 15) + (b * 20);
            System.out.println("Your bill is "+a);
        } 
    }
}
