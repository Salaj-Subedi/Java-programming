public abstract class Shape

{
public abstract int RectangleArea(int l, int b);
public abstract float CircleArea(float r);
public abstract int SquareArea(int s);
}




