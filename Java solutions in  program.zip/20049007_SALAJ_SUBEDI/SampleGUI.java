
 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.ButtonGroup;

public class SampleGUI implements ActionListener
{
    //creating instance variables to be used in different methods. if declared in previous ways we couldnt use
    //in other methods as local variable is declared and used only inside the method in which it is declared.
    public static SampleGUI info = new SampleGUI();
    private JFrame f;private JPanel p;   
    private JLabel fname,lname,gender,street1,street2,city,country,zipcodes;
    private JTextField fnametxt,lnametxt,street1txt,street2txt,citytxt,zipcodestxt;
    private JButton okbtn,cancelbtn,regbtn;
    private JComboBox item;
    private ButtonGroup bg;
    private JOptionPane msg1,msg2,msg3,msg4;    
    public static void main(String[]args)
    {
        info.creategui(); 
    }

    public  void creategui(){
        Font SID = new Font("Times New Roman",Font.BOLD,16);
        f = new JFrame("My Frame");

        p = new JPanel();
        p.setBounds(1, 1, 400,300);
        p.setLayout(null);
        
        p.setBorder(BorderFactory.createTitledBorder("User Information Form"));
        
        fname=new JLabel("First Name ");
        fname.setBounds(20,60,80,30);
        p.add(fname);

        fnametxt = new JTextField("FirstName");
        fnametxt.setBounds(120,60,180,30);
        p.add(fnametxt);

        lname=new JLabel("Last Name ");
        lname.setBounds(20,100,80,30);
        p.add(lname);

        lnametxt = new JTextField("Last Name");
        lnametxt.setBounds(120,100,180,30);
        p.add(lnametxt);

        gender=new JLabel("Gender:");
        gender.setBounds(20,140,80,20);
        p.add(gender);

        //JRadioButton---male
        JRadioButton Mbutton=new JRadioButton("Male");
        Mbutton.setBounds(120,140,80,20);  

        //Jradio female
        JRadioButton Fbutton=new JRadioButton("Female");
        Fbutton.setBounds(220,140,80,20);

        //button group 
        ButtonGroup bg=new ButtonGroup();
        bg.add(Mbutton);
        bg.add(Fbutton);
        p.add(Mbutton);
        p.add(Fbutton);

        street1=new JLabel("street 1");
        street1.setBounds(20,180,80,30);
        p.add(street1);

        street1txt = new JTextField("Street1");
        street1txt.setBounds(120,180,180,30);
        p.add(street1txt);

        street2=new JLabel("Street 2  ");
        street2.setBounds(20,220,80,30);
        p.add(street2);

        street2txt = new JTextField("Street2");
        street2txt.setBounds(120,220,180,30);
        p.add(street2txt);

        city=new JLabel("City ");
        city.setBounds(20,260,80,20);
        p.add(city);

        citytxt = new JTextField("City");
        citytxt.setBounds(120,260,180,30);
        p.add(citytxt);

        zipcodes=new JLabel("Zip Codes ");
        zipcodes.setBounds(310,265,80,20);
        p.add(zipcodes);

        zipcodestxt = new JTextField("ZipCode");
        zipcodestxt.setBounds(380,260,60,30);
        p.add(zipcodestxt);

        country=new JLabel("Country");
        country.setBounds(20,300,180,20);
        p.add(country);

        String[] year ={"NEPAL","INDIA","CHINA","BHUTAN",};
        JComboBox js = new JComboBox(year);
        js.setBounds(120,300,180,30);
        p.add(js);

        okbtn= new JButton("OK");
        okbtn.setBounds(140,380,60,30);
        okbtn.addActionListener(this);
        p.add(okbtn);

        cancelbtn = new JButton("Cancel");
        cancelbtn.setBounds(210,380,90,30);
        cancelbtn.addActionListener(this);
        p.add(cancelbtn);

        regbtn = new JButton("Register me Later");
        regbtn.setBounds(310,380,160,30);
        regbtn.addActionListener(this);
        p.add(regbtn); 


        f.add(p);
        f.setBounds(10, 10, 550, 500);
        f.setResizable(false);
        f.setVisible(true);
    }
    //implementing the action performed method  
    public void actionPerformed(ActionEvent e)
    {
        
        if(e.getSource()== okbtn)
        {
            msg4=new JOptionPane();
            msg4.showMessageDialog(f,"The information is sucessfully registered");

        }

        
        else if(e.getSource()== cancelbtn)
        {
            msg4=new JOptionPane();
            msg4.showMessageDialog(f,"You Cancelled");

        }
        
        else if(e.getSource()== regbtn)
        {
            msg4=new JOptionPane();
            msg4.showMessageDialog(f,"Your registration will be done later");

        }      
    }
}