class Area extends Shape{
public int RectangleArea(int l, int b){
return l*b;
}
public float CircleArea(float r){
return 3.14f*r*r;
}
public int SquareArea(int s){
return s*s;
}
public static void main(String []args) {
Area area = new Area();
System.out.println(area.RectangleArea(5, 10));
System.out.println(area.CircleArea(10));
System.out.println(area.SquareArea(10));

}
}