public class Cylinder
{
    int height = 10;
    int radius = 10;
    
    public void volume()
    {
        double pi = 3.14;
        double volume = pi*radius*radius*height;
        {
            System.out.println("The volume of cylinder is "+volume);
        }
    }
    public void setHeight(int height)
    {
        if (height > 0)
        {
            this.height = height;
        }
        else
        {
            System.out.println("Input the valid number ");
        }
    }
    public void setRadius(int radius)
    {
        if (radius > 0)
        {
            this.radius = radius;
        }
        else
        {
            System.out.println("Input the valid number ");
        }
    }
    public int getHeight()
    {
        return
        this.height = height;
    }
    public int
    setRadius()
    {
        return
        this.radius = radius;
    }
}
