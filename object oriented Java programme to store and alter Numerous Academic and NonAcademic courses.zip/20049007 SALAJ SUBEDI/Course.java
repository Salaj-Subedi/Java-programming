package c;


/**
 * Write a description of class Course here.
 *
 * @author (Salaj Subedi)
 * @version (a version number or a date)
 */
public class Course
{
     String CourseID;
     String CourseName;
     String CourseLeader;
     int Duration;
    
    public Course(String CourseID,String CourseName,int Duration){//constructors
    this.CourseID=CourseID;
    this.CourseName=CourseName;
    this.Duration=Duration;
    CourseLeader="";
    }
    //method for setting new courseleader
    public void setCourseLeader(String CourseLeader){
    this.CourseLeader=CourseLeader;
    }
    public String getCourseID(){//accessor method for CourseID
        return CourseID;
    }
    public String getCourseName(){//accessor method for CourseName
        return CourseName;
    }
    public String getCourseLeader(){//accessor method for CourseLeader
        return CourseLeader;
    }
    public int getDuration(){//acessor method for CourseDuration
        return Duration;
    }
    public void display()//DISPLAYS CourseID,CourseName,CourseDuration and CourseLeader if it is not empty set.
    {
        System.out.println("The CourseID is  "+this.CourseID) ;
        System.out.println("The CourseName is "+this.CourseName); 
        System.out.println("The Duration is  "+this.Duration+" hours"); 
            if (CourseLeader==""){
            System.out.println("Enter the CourseLeader name to be displayed");
        }
         else{
             System.out.println("The name of CourseLeader is "+this.CourseLeader);
        }
    }
}
