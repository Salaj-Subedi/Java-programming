package c;


/**
 * Write a description of class NonAcademicCourse here.
 *
 * @author (Salaj Subedi)
 * @version (a version number or a date)
 */
public class NonAcademicCourse extends Course
{
    private String  InstructorName;
    private float   duration;
    private String  StartDate;
    private String  CompletionDate;
    private String  ExamDate;
    private String  Prerequisite;
    private boolean isRegistered;
    private boolean isRemoved;
    
    public NonAcademicCourse(String CourseID,String CourseName,int Duration, String Prerequisite)//constructor being assigned parameters
    {//constructors being assigned values
        super(CourseID,CourseName,Duration);
        this.InstructorName=InstructorName;
        this.duration=duration;
        this.Prerequisite=Prerequisite;
        this.StartDate="";
        this.CompletionDate="";
        this.ExamDate="";
        this.isRegistered=false;
        this.isRemoved=false; 
    }
    public String getInstructorName() /** accessor method of attribute InstructorName */ 
    {
        return InstructorName;
    }

    public float getduration() /** accessor method of attribute Duration */
    {
        return duration;
    }

    public String getPrerequisite() /** accessor method of attribute Prerequisites */
    {
        return Prerequisite;
    }

    public String getStartDate() /** accessor method of attribute start date */
    {
        return StartDate;
    }

    public String getCompletionDate() /** accessor method of attribute End date */
    {
        return CompletionDate;
    }

    public String getExamDate() /** accessor method of attribute ExamDate*/
    {
        return ExamDate;
    }

    public boolean getisRegistered() /** accessor method of attribute isregistered */
    {
        return isRegistered;
    }
    public boolean getisRemoved() /**accessor method of attribute isRemoved */
    {
        return isRemoved;
    }
    public void setInstructorName(String InstructorName) /** mutator method of attribute InstructorName */
    {
         if(isRegistered==false){
            this.InstructorName=InstructorName;
            System.out.println("instructor name changed");
        }else{
            System.out.println(InstructorName+"cannot be changed as the new Non academic course is already registered");

        }
    }
    public void registerNonAcademicCourse(String CourseLeader,String InstructorName,String StartingDate,String CompletionDate,String ExamDate) /** registers a course if the course is not registered i.e. isRegistered=false */
   {

        if(isRegistered==true){
           System.out.println("The course has already been taken by"+this.InstructorName+" starting from "+this.StartDate+" upto "+this.CompletionDate);
          
        }else if(isRegistered==false){
            super.setCourseLeader(CourseLeader);
            this.InstructorName=InstructorName;
            this.StartDate=StartingDate;
            this.CompletionDate=CompletionDate;
            this.ExamDate=ExamDate;
            isRegistered=true;
            boolean CourseRemoves=false;
            System.out.println("You have successfully registered a NonAcademicCourse whose leader is "+CourseLeader+", InstructorName is "+InstructorName+", Start date and Completion dates are "+StartDate+" "+CompletionDate); 
                   
            }
       }
       public void removeNonAcademicCourse(){ /**Removes NonAcademic Course if not been removed already i.e. isRemoved=true*/
            if(isRemoved==true){
                System.out.println("The NonAcademicCourse  is already Removed");   
            }else{
                System.out.println("The Courseleader "+CourseLeader+" has been terminated ");
                super.setCourseLeader("");
                StartDate="";
                InstructorName="";
                CompletionDate="";
                ExamDate="" ;
                isRegistered=false;
                isRemoved=true;
            }
        }
        public void display() /**displays the details of course from super class and if Non Academic course is already registred displayes the details of course such as Instructor name,start/end date,Exam date */
       {
            super.display();
            if(isRegistered==true){
                System.out.println("InstructorName= "+getInstructorName());
                System.out.println("StartDate= "+getStartDate());
                System.out.println("EndDate= "+getCompletionDate());
                System.out.println("ExamDate= "+getExamDate());
            }
        }
    }
