package c;


/**
 * Write a description of class AcademicCourse here.
 *
 * @author (Salaj Subed)
 * @version (a version number or a date)
 */
public class AcademicCourse extends Course{//AcademicCourse sub class of super class Course
   private String LecturerName;
   private String Level;
   private String Credit;
   private String StartingDate;
   private String CompletionDate;
   private float NumberofAssessments;
   private boolean isRegistered;
    //constructors being assigned below
   public AcademicCourse(String CourseID , String CourseName , int Duration ,String Level, String Credit, float NumberofAssessments)
   {
    super(CourseID,CourseName,Duration);
    this.LecturerName=LecturerName;
    this.Level=Level;
    this.Credit=Credit;
    this.NumberofAssessments=0.0f;
    this.StartingDate="";
    this.CompletionDate="";
    this.isRegistered=false;
   }
   public String getLecturerName()//accessor method for lecturer name
   {
       return LecturerName;
    }
   public String getLevel()//accessor method for level
   {
       return Level;
    }
    public String getCredit()//accessor method for Credit
   {
       return Credit;
    }
    public float getNumberofAssessments()//accessor method for NumberofAssessments
   {
       return NumberofAssessments;
    }
    public String getStartingDate()//accessor method for StartingDate
   {
       return StartingDate;
    }
    public String getCompletionDate()//accessor method for CompletionDate
   {
       return CompletionDate;
    }
   public boolean getisRegistered()//accessor method for isRegistered
   {
       return isRegistered;
   }
   public void setLecturerName(String LecturerName) /** method to adopt changes in LecturerName*/
    {
        this.LecturerName=LecturerName;
    }
   public void setNumberofAssessments(float NumberofAssessments)//method to adopt changes in number of assessments
   {
       this.NumberofAssessments=NumberofAssessments;
    }
   public void registerAcademicCourse(String CourseLeader,String LecturerName,String StartingDate,String CompletionDate) /** registers a course if the course is not registered i.e. isRegistered=false */
    {

        if(isRegistered==true){
            System.out.println("The course is registered and has already been taken by"+this.LecturerName+" starting from "+this.StartingDate+" upto "+this.CompletionDate);
        }else if(isRegistered==false){
            super.setCourseLeader(CourseLeader);
            this.LecturerName=LecturerName;
            this.StartingDate=StartingDate;
            this.CompletionDate=CompletionDate;
            isRegistered=true;
            boolean CourseRemoved=false;
            System.out.println("You have successfully registered a AcademicCourse whose Courseleader is "+super.CourseLeader+"lecturer is "+LecturerName);
               
        }
   }
   public void display() /**displays the details of course from super class and if course is already registred displayes thedetails of course such as lecturer name,level,credit,start/end date,no.of assessments */
   {
        super.display();
        if(isRegistered==true){
            System.out.println("LecturerName = "+getLecturerName());
            System.out.println("Level= "+getLevel());
            System.out.println("Credit= "+getCredit());
            System.out.println("StartingDate= "+getStartingDate());
            System.out.println("CompletionDate "+getCompletionDate());
            System.out.println("NumberofAssessments "+getNumberofAssessments());
        }
   }
   
}
